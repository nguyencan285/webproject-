<footer>
    <ul class="nav-footer">
        <li class="copyright"><img width="20px" src="../assets/images/ic-copyright.png" alt=""> 2023 Bello</li>
        <li><a href="./shop.php">Shop</a></li>
        <li><a href="./blog.php">Blog</a></li>
        <li><a href="./contact.php">Contact</a></li>
        <li><a href="./reviews.php">Reviews</a></li>
    </ul>
    <div class="contact-app">
        <a href=""><img width="20px" src="../assets/images/ic-tw.png" alt=""></a>
        <a href=""><img width="10px" src="../assets/images/ic-fb.png" alt=""></a>
        <a href=""><img width="17px" src="../assets/images/ic-ins.png" alt=""></a>
        <a href=""><img width="18px" src="../assets/images/ic-pin.png" alt=""></a>
        <a href=""><img width="29px" src="../assets/images/ic-gg.png" alt=""></a>
    </div>
</footer>