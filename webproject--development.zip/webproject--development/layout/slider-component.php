<section class="slider">
    <div class="slider-images">
        <input type="radio" name="slide" id="img1">
        <input type="radio" name="slide" id="img2">
        <input type="radio" name="slide" id="img3">
        <input type="radio" name="slide" id="img4">

        <img id="image-1" class="image-1" src="../assets/images/slider0.jpg" alt="">
        <img id="image-2" class="image-2" src="../assets/images/slider1.jpg" alt="">
        <img id="image-3" class="image-3" src="../assets/images/slider.jpg" alt="">
        <img id="image-4" class="image-4" src="../assets/images/slider3.jpg" alt="">
    </div>
    <div class="slider-nav">
        <label for="img1"></label>
        <label for="img2"></label>
        <label for="img3"></label>
    </div>
</section>